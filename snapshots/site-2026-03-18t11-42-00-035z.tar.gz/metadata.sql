BEGIN;
-- users
INSERT INTO users (username, display_name, quota_gb, enabled, home_dir, source, updated_at) VALUES ('admin', 'Administrator', 20, TRUE, 'admin', 'cloud-config', '2026-03-18T11:42:00.021Z');
INSERT INTO users (username, display_name, quota_gb, enabled, home_dir, source, updated_at) VALUES ('test', 'Test User', 20, TRUE, 'test', 'cloud-config', '2026-03-18T11:42:00.026Z');
-- shares
-- node_status
INSERT INTO node_status (node_id, base_url, enabled, tags, version, environment, started_at, last_heartbeat, storage_mounted, storage_root, database_ok, metadata) VALUES ('node-local', 'http://localhost:3000', TRUE, ARRAY['primary', 'development'], '0.1.0', 'development', '2026-03-18T11:41:59.898Z', '2026-03-18T11:42:00.034Z', TRUE, 'C:\Users\WEBRAI~1\AppData\Local\Temp\magus-backup-test-KvzmCm\storage', TRUE, '{"appName":"Magus Cloud"}'::jsonb);
-- backup_snapshots
INSERT INTO backup_snapshots (snapshot_id, kind, username, archive_path, manifest_path, status, checksum, metadata, created_at) VALUES ('site-2026-03-18t11-42-00-035z', 'site', NULL, 'F:\magus\Magus-Cloud\snapshots\site-2026-03-18t11-42-00-035z.tar.gz', 'F:\magus\Magus-Cloud\snapshots\site-2026-03-18t11-42-00-035z.manifest.json', 'running', '', '{}'::jsonb, '2026-03-18T11:42:00.039Z');
-- ops_events
-- applied_config_versions
INSERT INTO applied_config_versions (config_version, config_path, node_id, id, applied_at) VALUES ('c8abbaf38e2855268fc11ee79cc39ae7a9ea99c9', 'F:\magus\Magus-Cloud\config\magus.config.json', 'node-local', 1, '2026-03-18T11:42:00.027Z');
-- app_settings
COMMIT;
