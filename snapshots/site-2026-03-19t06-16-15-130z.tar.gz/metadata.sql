BEGIN;
-- users
INSERT INTO users (username, display_name, quota_gb, enabled, home_dir, source, updated_at) VALUES ('admin', 'Administrator', 20, TRUE, 'admin', 'cloud-config', '2026-03-19T06:16:15.117Z');
INSERT INTO users (username, display_name, quota_gb, enabled, home_dir, source, updated_at) VALUES ('test', 'Test User', 20, TRUE, 'test', 'cloud-config', '2026-03-19T06:16:15.120Z');
-- shares
-- node_status
INSERT INTO node_status (node_id, base_url, enabled, tags, version, environment, started_at, last_heartbeat, storage_mounted, storage_root, database_ok, metadata) VALUES ('node-local', 'http://localhost:3000', TRUE, ARRAY['primary', 'development'], '0.1.0', 'development', '2026-03-19T06:16:15.049Z', '2026-03-19T06:16:15.129Z', TRUE, 'C:\Users\WEBRAI~1\AppData\Local\Temp\magus-backup-test-2DuijI\storage', TRUE, '{"appName":"Magus Cloud"}'::jsonb);
-- backup_snapshots
INSERT INTO backup_snapshots (snapshot_id, kind, username, archive_path, manifest_path, status, checksum, metadata, created_at) VALUES ('site-2026-03-19t06-16-15-130z', 'site', NULL, 'F:\magus\Magus-Cloud\snapshots\site-2026-03-19t06-16-15-130z.tar.gz', 'F:\magus\Magus-Cloud\snapshots\site-2026-03-19t06-16-15-130z.manifest.json', 'running', '', '{}'::jsonb, '2026-03-19T06:16:15.134Z');
-- ops_events
-- applied_config_versions
INSERT INTO applied_config_versions (config_version, config_path, node_id, id, applied_at) VALUES ('43e997073ea52335e387a016739d61b897413a9f', 'F:\magus\Magus-Cloud\config\magus.config.json', 'node-local', 1, '2026-03-19T06:16:15.122Z');
-- app_settings
COMMIT;
